README

Directories in this folder are templates for different versions of solr core
configurations for different versions of Drupal solr modules.

Name them like: [major drupal version]-[module shortname], so like d7-sapi.

In order to allow our solr-ac script to automatically provision new cores, the
<dataDir> should contain the string "EXAMPLE_COM_DIR" where the core name should
be placed.
